RALPH CESAR SELLADO — PORTFOLIO WEBSITE

Updated with:
- Email: raprapsellado48@gmail.com
- GitHub repository: ralphcesarsellado.github.io

Publishing:
1. Upload index.html to the root of your GitHub repository.
2. Go to Settings > Pages.
3. Select "Deploy from a branch".
4. Select branch "main" and folder "/ (root)".
5. Save.

Expected website:
https://ralphcesarsellado.github.io/
